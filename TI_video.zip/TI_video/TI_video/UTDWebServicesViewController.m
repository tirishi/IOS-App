//
//  UTDWebServicesViewController.m
//  TI_video
//
//  Created by Mito Are on 10/31/13.
//  Copyright (c) 2013 Mito Are. All rights reserved.
//

#import "UTDWebServicesViewController.h"
#import "UTDResultsViewController.h"

@interface UTDWebServicesViewController ()

@property(retain,nonatomic) IBOutlet UITextField *product_family;
@property(retain,nonatomic) IBOutlet UIButton *product_button;
@property(retain,nonatomic) IBOutlet UITextField *part;
@property(retain,nonatomic) IBOutlet UIButton *part_button;
@property(retain,nonatomic) IBOutlet UITextField *tool;
@property(retain,nonatomic) IBOutlet UIButton *tool_button;
@property(retain,nonatomic) IBOutlet UITextField *application;
@property(retain,nonatomic) IBOutlet UIButton *application_button;
@property(retain,nonatomic) IBOutlet UITextField *keyword;
@property(retain,nonatomic) IBOutlet UIButton *keyword_button;

@end

@implementation UTDWebServicesViewController

//@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
- (IBAction)processInput:(id)sender
{
    UTDResultsViewController *ResultsView = [self.storyboard instantiateViewControllerWithIdentifier:@"utdResultsViewController"];
    ResultsView.UrlOutputLabel.text = @"Sample";
    [self.navigationController pushViewController:ResultsView animated:YES];

    //[delegate changeLabelFromWebService:self newString:@"Sample"];
    //NSString *fromTextField = self.product_family.text;
    //NSString *kaltura1 = @"http://www.kaltura.com/api_v3/?service=";
    //NSString *kaltura2 = @"&action=";
    //self.web.text = [NSString stringWithFormat: @"%@%@", kaltura1, kaltura2];
    self.web.text = self.product_family.text;
}
*/

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    UTDResultsViewController *ResultsView = [segue destinationViewController];
    
    if ([[segue identifier] isEqualToString:@"prodFam"])
    {
        NSString *userIn = self.product_family.text;
        //[self.product_family resignFirstResponder];
        //[[self view] endEditing:YES];
        NSString *http = @"PROD";//@"http://www.kaltura.com/api_v3/?service=playlist&action=list&filter:tagsLike=";
        ResultsView.forLabel = [http stringByAppendingString:userIn];
     
    }
    if ([[segue identifier] isEqualToString:@"gpn"])
    {
        NSString *userIn = self.part.text;
        NSString *http = @"GPN";//@"http://www.kaltura.com/api_v3/?service=playlist&action=list&filter:tagsLike="";
        ResultsView.forLabel = [http stringByAppendingString:userIn];
        
    }
    if ([[segue identifier] isEqualToString:@"tool"])
    {
        NSString *userIn = self.tool.text;
        NSString *http = @"TOOL";//@"http://www.kaltura.com/api_v3/?service=playlist&action=list&filter:tagsLike="";
        ResultsView.forLabel = [http stringByAppendingString:userIn];
        
    }if ([[segue identifier] isEqualToString:@"app"])
    {
        NSString *userIn = self.application.text;
        NSString *http = @"APP";//@"http://www.kaltura.com/api_v3/?service=playlist&action=list&filter:tagsLike="";
        ResultsView.forLabel = [http stringByAppendingString:userIn];
        
    }if ([[segue identifier] isEqualToString:@"keywords"])
    {
        NSString *userIn = self.keyword.text;
        NSString *http = @"KEYS";//@"http://www.kaltura.com/api_v3/?service=playlist&action=list&filter:tagsLike="";
        ResultsView.forLabel = [http stringByAppendingString:userIn];
        
    }
}

@end
