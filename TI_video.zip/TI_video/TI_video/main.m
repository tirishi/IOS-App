//
//  main.m
//  TI_video
//
//  Created by Mito Are on 10/29/13.
//  Copyright (c) 2013 Mito Are. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UTDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([UTDAppDelegate class]));
    }
}
