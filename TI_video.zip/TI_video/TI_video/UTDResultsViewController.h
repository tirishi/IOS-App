//
//  UTDResultsViewController.h
//  TI_video
//
//  Created by Mito Are on 10/31/13.
//  Copyright (c) 2013 Mito Are. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UTDWebServicesViewController.h"

@interface UTDResultsViewController : UIViewController
{
    UILabel *UrlOutputLabel;
    UILabel *ApiCallOutputLabel;
    UILabel *XmlOutputLabel;
    NSString *forLabel;
}

@property(retain,nonatomic) IBOutlet UILabel *UrlOutputLabel;
@property(retain,nonatomic) IBOutlet UILabel *ApiCallOutputLabel;
@property(retain,nonatomic) IBOutlet UILabel *XmlOutputLabel;
@property(retain,nonatomic) NSString *forLabel;


@end
